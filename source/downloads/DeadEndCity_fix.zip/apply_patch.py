#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DeadEndCity 汉化版「首次游玩牌组退化」修复补丁
==============================================

症状
----
没跑过原版时，汉化版首次进入新游戏后：
  * 战斗手牌只有 3 张「拳头」，图标全同
  * 牌堆计数为 0（整套牌就 3 张）
  * 三选一选中的稀有卡不会进入牌组
必须在原版里先选一张卡、让原版写出合法存档，汉化版才正常。

根因
----
游戏用 IL2CPP 字符串字面量作为卡牌内部键来构建初始牌组。
汉化工具把其中 3 条当普通文本翻译掉了：
    リロード   -> 重新加载
    手癖       -> 顺手牵羊
    隠れる     -> 隐藏
而 data.unity3d 卡牌定义表里的内部键仍是日文，查表落空 ->
新游戏初始化中断 -> 牌组退化成 3 张兜底牌。

修复
----
把 global-metadata.dat 里这 3 条字面量还原成日文原文：
  追加字符串到字面量数据块末尾 + 改这 3 条的索引 + 更新头部 dataSize。
其余 10014 条字面量一个字节都不动，补丁后文件仅大 27 字节。

用法
----
  # 全自动修复一个游戏目录（缺 exe 就补，再打元数据补丁）
  python apply_patch.py "F:\\GAMES\\RuinCity"

  # 只检查补丁状态，不改任何文件
  python apply_patch.py --verify "F:\\GAMES\\RuinCity"

  # 只给某个 global-metadata.dat 打补丁
  python apply_patch.py --meta "路径\\global-metadata.dat"

  # 只给某个 global-metadata.dat 查状态
  python apply_patch.py --verify --meta "路径\\global-metadata.dat"

脚本是幂等的：已打好补丁的文件会被识别并跳过，不会重复追加。
"""

import os
import struct
import sys

# 目标字面量索引 -> (被汉化后的错误值, 应该还原成的原文)
# 索引对应卡牌表 data.unity3d 里 resources.assets pid 2090 / 2099 / 2106 的内部键
TARGETS = {
    9508: ('重新加载', 'リロード'),
    9646: ('顺手牵羊', '手癖'),
    9851: ('隐藏', '隠れる'),
}

META_REL = os.path.join('DeadEndCity_Data', 'il2cpp_data', 'Metadata', 'global-metadata.dat')
EXE_NAME = 'DeadEndCity.exe'


# ---------------------------------------------------------------- 元数据解析

def parse_header(data):
    """返回 (字面量索引表偏移, 表大小, 数据块偏移, 数据块大小)。"""
    if len(data) < 0x18:
        raise ValueError('文件太小，不是 IL2CPP 元数据')
    sanity, version = struct.unpack_from('<II', data, 0)
    if sanity != 0xFAB11BAF:
        raise ValueError(f'魔数不对 (0x{sanity:08X})，不是 IL2CPP 元数据')
    lit_off, lit_size, data_off, data_size = struct.unpack_from('<IIII', data, 8)
    return lit_off, lit_size, data_off, data_size


def read_literal(data, lit_off, data_off, index):
    """读出第 index 条字面量；长度为 0 表示空条目。"""
    length, offset = struct.unpack_from('<Ii', data, lit_off + index * 8)
    if length <= 0:
        return None
    return bytes(data[data_off + offset:data_off + offset + length])


def count_literals(data):
    lit_off, lit_size, data_off, data_size = parse_header(data)
    return lit_size // 8, lit_off, data_off, data_size


def classify(data):
    """
    判断元数据当前状态。
    返回 (status, details)
      status: 'patched'  已修复
              'broken'   存在被误译的字面量，需要修复
              'unknown'  目标字面量与预期都不符
    details: [(index, 当前值, 期望状态)] ，期望状态为 'broken'/'patched'
    """
    n, lit_off, data_off, _ = count_literals(data)
    details = []
    any_broken = False
    any_unknown = False
    for index in sorted(TARGETS):
        translated, original = TARGETS[index]
        if index >= n:
            details.append((index, None, 'unknown'))
            any_unknown = True
            continue
        cur = read_literal(data, lit_off, data_off, index)
        if cur == original.encode('utf-8'):
            details.append((index, original, 'patched'))
        elif cur == translated.encode('utf-8'):
            details.append((index, translated, 'broken'))
            any_broken = True
        else:
            shown = cur.decode('utf-8', 'replace') if cur is not None else None
            details.append((index, shown, 'unknown'))
            any_unknown = True
    if any_broken:
        return 'broken', details
    if any_unknown:
        return 'unknown', details
    return 'patched', details


# ---------------------------------------------------------------- 打补丁

def make_patch(data):
    """
    生成打好补丁的字节串。
    返回 (新字节串, [(index, 旧值, 新值)])。已修复则变化列表为空。
    """
    data = bytearray(data)
    n, lit_off, data_off, data_size = count_literals(data)
    if data_off + data_size != len(data):
        raise ValueError(
            f'字面量数据块不在文件末尾 (dataOff={data_off} dataSize={data_size} '
            f'文件={len(data)})，文件结构与预期不符，已中止以免写坏。')

    changes = []
    blob = bytearray()
    newoff = data_size
    for index in sorted(TARGETS):
        translated, original = TARGETS[index]
        if index >= n:
            raise ValueError(f'字面量索引 {index} 超出范围（共 {n} 条）')
        cur = read_literal(data, lit_off, data_off, index)
        want = original.encode('utf-8')
        if cur == want:
            continue                                    # 已修复
        if cur != translated.encode('utf-8'):
            got = cur.decode('utf-8', 'replace') if cur is not None else None
            raise ValueError(
                f'第 {index} 条字面量是 {got!r}，既不等于被误译的 {translated!r}，'
                f'也不等于原文 {original!r}；可能不是同一个汉化版本，已中止。')
        struct.pack_into('<Ii', data, lit_off + index * 8, len(want), newoff)
        blob += want
        newoff += len(want)
        changes.append((index, translated, original))

    if not changes:
        return bytes(data), []

    data += blob
    struct.pack_into('<I', data, 0x14, newoff)          # header.stringLiteralDataSize
    return bytes(data), changes


# ---------------------------------------------------------------- 安装

def find_meta(game_root):
    p = os.path.join(game_root, META_REL)
    return p if os.path.isfile(p) else None


def install(game_root, do_write=True):
    """修复一个游戏目录。返回退出码。"""
    game_root = os.path.abspath(game_root)
    print(f'游戏目录: {game_root}')
    if not os.path.isdir(os.path.join(game_root, 'DeadEndCity_Data')):
        print('  [X] 找不到 DeadEndCity_Data\\，这不像游戏根目录。')
        return 1

    rc = 0

    # --- 1. 启动器 ---
    exe_dst = os.path.join(game_root, EXE_NAME)
    if os.path.isfile(exe_dst):
        print(f'  [=] {EXE_NAME} 已存在，跳过')
    else:
        exe_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), EXE_NAME)
        if os.path.isfile(exe_src):
            if do_write:
                import shutil
                shutil.copy2(exe_src, exe_dst)
                print(f'  [+] 已补上缺失的 {EXE_NAME}')
            else:
                print(f'  [!] 缺少 {EXE_NAME}（需要修复）')
                rc = 2
        else:
            print(f'  [X] 游戏缺少 {EXE_NAME}，补丁包里也没有，请从原版复制一份。')
            rc = 1

    # --- 2. 元数据 ---
    meta = find_meta(game_root)
    if not meta:
        print(f'  [X] 找不到 {META_REL}')
        return 1

    data = open(meta, 'rb').read()
    try:
        status, details = classify(data)
    except ValueError as e:
        print(f'  [X] {e}')
        return 1

    for index, value, state in details:
        mark = {'patched': '[=]', 'broken': '[!]', 'unknown': '[?]'}[state]
        note = {'patched': '已是原文', 'broken': '被误译，需修复',
                'unknown': '与预期不符'}[state]
        print(f'  {mark} lit[{index}] = {value!r}  ({note})')

    if status == 'patched':
        print('  [=] 元数据已修复，无需改动')
        return rc

    if status == 'unknown':
        print('  [X] 目标字面量与预期都不符，可能不是同一个汉化版本，已中止。')
        return 1

    if not do_write:
        print('  [!] 元数据需要打补丁（--verify 模式未写入）')
        return 2

    try:
        new_data, changes = make_patch(data)
    except ValueError as e:
        print(f'  [X] {e}')
        return 1

    bak = meta + '.bak'
    if not os.path.exists(bak):
        open(bak, 'wb').write(data)
        print(f'  [+] 已备份原文件 -> {os.path.basename(bak)}')
    open(meta, 'wb').write(new_data)
    print(f'  [+] 已打补丁: {len(data)} -> {len(new_data)} 字节 (+{len(new_data) - len(data)})')
    for index, old, new in changes:
        print(f'        lit[{index}]  {old} -> {new}')

    # --- 3. 复核 ---
    check, details = classify(open(meta, 'rb').read())
    if check != 'patched':
        print('  [X] 复核失败，补丁未生效！请用 .bak 还原。')
        return 1
    print('  [OK] 复核通过，补丁已生效')
    return rc


def verify_only(target):
    """只检查状态，不写任何文件。"""
    if os.path.isdir(target):
        meta = find_meta(target)
        if not meta:
            print(f'找不到 {META_REL}')
            return 1
        exe = os.path.isfile(os.path.join(target, EXE_NAME))
        print(f'游戏目录: {os.path.abspath(target)}')
        print(f'  {EXE_NAME}: {"有" if exe else "缺失"}')
    else:
        meta = target

    data = open(meta, 'rb').read()
    try:
        status, details = classify(data)
    except (ValueError, struct.error) as e:
        print(f'元数据: {meta}  ({len(data)} 字节)')
        print(f'  [X] 无法解析: {e}')
        return 1
    print(f'元数据: {meta}  ({len(data)} 字节)')
    for index, value, state in details:
        mark = {'patched': '[=]', 'broken': '[!]', 'unknown': '[?]'}[state]
        print(f'  {mark} lit[{index}] = {value!r}')
    verdict = {'patched': '已修复', 'broken': '未修复（需要打补丁）',
               'unknown': '与预期不符'}[status]
    print(f'结论: {verdict}')
    return 0 if status == 'patched' else 2


# ---------------------------------------------------------------- 入口

def main(argv):
    args = [a for a in argv[1:] if not a.startswith('--')]
    flags = {a for a in argv[1:] if a.startswith('--')}
    verify = '--verify' in flags
    meta_only = '--meta' in flags

    if not args or '--help' in flags or '-h' in flags:
        print(__doc__)
        return 0 if args else 1

    target = args[0]

    if meta_only and verify:
        return verify_only(target)
    if meta_only:
        if not os.path.isfile(target):
            print(f'找不到文件: {target}')
            return 1
        data = open(target, 'rb').read()
        try:
            status, _ = classify(data)
        except (ValueError, struct.error) as e:
            print(f'[X] 无法解析 {target}: {e}')
            return 1
        if status == 'patched':
            print('已是修复状态，无需改动。')
            return 0
        if status == 'unknown':
            print('目标字面量与预期不符，已中止。')
            return 1
        try:
            new_data, changes = make_patch(data)
        except (ValueError, struct.error) as e:
            print(f'[X] {e}')
            return 1
        bak = target + '.bak'
        if not os.path.exists(bak):
            open(bak, 'wb').write(data)
            print(f'已备份 -> {bak}')
        open(target, 'wb').write(new_data)
        for index, old, new in changes:
            print(f'  lit[{index}]  {old} -> {new}')
        print(f'完成: {len(data)} -> {len(new_data)} 字节')
        return 0

    if verify:
        return verify_only(target)
    return install(target)


if __name__ == '__main__':
    sys.exit(main(sys.argv))
